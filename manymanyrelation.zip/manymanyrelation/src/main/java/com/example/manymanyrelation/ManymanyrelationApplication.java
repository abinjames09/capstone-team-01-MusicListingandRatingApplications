package com.example.manymanyrelation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManymanyrelationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManymanyrelationApplication.class, args);

		System.out.println("Running");
	}

}
